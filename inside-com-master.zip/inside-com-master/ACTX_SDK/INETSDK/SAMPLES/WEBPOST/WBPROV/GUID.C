#define INITGUID

#include <ole2.h>
#include <wpguid.h>

